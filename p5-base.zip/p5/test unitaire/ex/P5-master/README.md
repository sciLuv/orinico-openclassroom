
# ORINOCO

OricoBears est un site d'e-commerce spécialisé dans la vente de pelluches faite à la main.

le site est composé de 6 pages : 

- La page de présentation du site (index.html)
- La page de la liste des produits permettant de selectionner un article au click sur une image.(listeproduit.html)

- La page produit avec le detail du produit et possibilité :
    - d'ajout au panier,
    - modification de la couleur.
    
- La page panier regroupant les articles ajoutés au panier et possibilité :
    - de supprimmer des articles,
    - de modifier la quantité,
    - de valider le panier.
    
- La page formulaire récuperant les informations de contact dans un formulaire avant la confirmation de la commande.

- La page confirmation de commande affichant le résumé de la commmande.

installer node js
ensuite taper la commande cd backend
taper npm install
taper node server
vous êtes connecté au serveur
rendez vous sur la page suivante : https://martineboulenger.github.io/P5/index.html